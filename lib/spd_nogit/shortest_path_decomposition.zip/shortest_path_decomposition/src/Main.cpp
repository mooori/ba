#include <stdlib.h>
#include <iostream>
#include <iterator>
#include <utility>
#include <string>
#include <queue>
#include <stack>

#include "Common.h"
#include "../include/TestGraphs.hpp"
#include "../include/ShortestPathDecomposition.hpp"

int main(int argc, char* argv[])
{
    bool test, viz;
    test = false;
    viz = false;
    int debug, n, k, choose_arb_mode, wcol, wcol_mode;
    debug = 0;
    n = 0;
    k = 0;
    choose_arb_mode = 0;
    wcol = 0;
    wcol_mode = 0;
    std::string file;
    //using namespace std::chrono;
    
    time_t start;
    time(&start);
    
    if (std::string(argv[1]) == "-gridn" || std::string(argv[1]) == "-kn" || std::string(argv[1]) == "-forest") {
        
        n = atoi(argv[2]);
        if (std::string(argv[3]) == "-test") 
            test = true;
        else 
            test = false;
        
        debug = atoi(argv[4]);
        
        if (std::string(argv[5]) == "-viz") 
            viz = true;
        else 
            viz = false;
        
        choose_arb_mode = atoi(argv[6]);
        
        wcol = atoi(argv[7]);
        
        wcol_mode = atoi(argv[8]);
    }
    else if (std::string(argv[1]) == "-sat") {
        file = std::string(argv[2]);
        
        if (std::string(argv[3]) == "-test") 
            test = true;
        else 
            test = false;
        
        debug = atoi(argv[4]);
        
        if (std::string(argv[5]) == "-viz") 
            viz = true;
        else 
            viz = false;
        
        choose_arb_mode = atoi(argv[6]);
        
        wcol = atoi(argv[7]);
        
        wcol_mode = atoi(argv[8]);
    }
    
    else if (std::string(argv[1]) == "-regnk") {
        n = atoi(argv[2]);
        k = atoi(argv[3]);
        if (std::string(argv[4]) == "-test") 
            test = true;
        else 
            test = false;
        
        debug = atoi(argv[5]);
        
        if (std::string(argv[6]) == "-viz") 
            viz = true;
        else 
            viz = false;
        
        choose_arb_mode = atoi(argv[7]);
        
        wcol = atoi(argv[8]);
        
        wcol_mode = atoi(argv[9]);
    }
        
    if (std::string(argv[1]) == "-gridn") {
        TestGraphs::runTestGrid(n, test, debug, viz, choose_arb_mode, wcol, wcol_mode); //test, debug, viz
    }
    
    else if (std::string(argv[1]) == "-forest") {
        TestGraphs::runForestRun(n, test, debug, viz, choose_arb_mode, wcol, wcol_mode); //test, debug, viz
    }
    
    else if (std::string(argv[1]) == "-kn") {
        TestGraphs::runTestKn(n, test, debug, viz, choose_arb_mode, wcol, wcol_mode); //test, debug, viz
    }
    
    else if (std::string(argv[1]) == "-sat") {
        TestGraphs::runTestSAT(file, test, debug, viz, choose_arb_mode, wcol, wcol_mode); //test, debug, viz
    }
    
    else if (std::string(argv[1]) == "-regnk") {
        TestGraphs::runTestReg(n,k, test, debug, viz, choose_arb_mode, wcol, wcol_mode); //test, debug, viz
    }
    
    
    time_t end;
    time(&end);
    
    time_t comp_time = end-start;
    
    std::cout << "Computation took " << comp_time << " seconds" << std::endl;
    
    std::cin.get();
    if (viz)
        ShortestPathDecomposition::Ubiviz::clear();
    return 0;
}